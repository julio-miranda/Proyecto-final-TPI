<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'codigo_de_producto' => Str::random(10),
            'nombre' => fake()->name(),
            'categorias'=> fake()->title(),
            'imagen_del_producto'=>fake()->imageUrl(),
            'proveedor' => fake()->name(),
            'stock'=> fake()->unique()->randomNumber(),
            'costo' => fake()->randomNumber(),
            'precio_de_venta' => fake()->randomNumber(), 
        ];
    }
}
