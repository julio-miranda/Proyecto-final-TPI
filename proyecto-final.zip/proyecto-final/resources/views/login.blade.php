<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Form</title>
</head>

<body>
    <div class="container">
        <br><br>
        <div class="card">
            <h5 class="card-header">Iniciar Sesion</h5>
            <div class="card-body">
                <p class="card-text">
                <form action="{{route('iniciar-sesion')}}" method="POST">
                    @csrf
                    <label for="email">Email: </label><input type="email" name="email" class="form-control" required><br>
                    <label for="pass">Password: </label><input type="password" name="password" class="form-control" required><br>
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </form>
                </p>
            </div>
        </div>
    </div>
</body>

</html>