<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    //
    public function login(Request $request){
        $credenciales =[
          'email'=>$request->email,
          'password'=> $request->password,
          //"activate"=>true  
        ];
        var_dump($credenciales);
/*        $remember = ($request->has('remember') ? true:false);
        if(Auth::attempt($credenciales,$remember)){
            $request->session()->regenerate();
            return redirect()->intended(route('privado'));
        }else{
            return redirect()->route('login');
        }*/
    }
    public function register(Request $request){
        $user = User::create([
            'nombre'=>$request->nombre,
            'edad'=>$request->edad,
            'genero'=>$request->genero,
            'fotografia'=>$request->fotografia,
            'email'=>$request->email,
            'users'=>$request->user,
            'pais'=>$request->pais,
            'direcciones de envio'=>$request->direccion,
            'password'=>Hash::make($request->password),
        ]);

        Auth::login($user);

        return redirect()->route('privado');
    }
    public function logout(Request $request){
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
